import turtle as t

screen = t.Screen()
screen.setup(800, 800)
screen.title("Jogo do Galo")

t.width(8)


def desenhar(largura, xi, yi):
    # code for inner lines of the square

    xi, yi = xi - largura / 6, yi - largura / 6  # metade do campo para baixo
    t.penup()
    t.goto(xi - largura / 3, yi)  # http://prntscr.com/1djqeb9
    t.pendown()

    t.forward(largura)

    t.penup()
    t.goto(xi - largura / 3, yi + largura / 3)
    t.pendown()

    t.forward(largura)

    t.penup()
    t.goto(xi, yi - largura / 3)
    t.pendown()

    t.left(90)
    t.forward(largura)

    t.penup()
    t.goto(xi + largura / 3, yi - largura / 3)
    t.pendown()

    t.forward(largura)

    desenharquad((largura/3)-largura/(3*4), 0, 0)


def desenharquad(comprimento, x, y):
    t.color('blue')
    t.up()
    t.goto((x - comprimento)/3, (y - comprimento)/3)  # tenho que dividir por 3 para estar no plano do jogo do galo
    t.down()

    t.seth(0)
    for x in range(4):
        t.forward(comprimento-comprimento/3)  # e dividir a largura do comprimento outra vez por 3 de modo a "caber" dentro do quadrado
        t.left(90)


desenhar(400, 0, 0)


t.done()
