import P

# 1.1 Dá print ao teu nome
print("Cristiano Ronaldo")
# 1.2 Comenta o print e vê o que acontece.


# 2 Guarda numa variavel o teu nome e dá print dessa variavel
nome = "Cristiano Ronaldo"
print(nome)

# 3 Guarda o teu primeiro e último nome em duas variaveis diferentes do tipo string e dá print aos dois
# Podes aprensentar + que 1 solução
a = "aos"
b = "baroes"
print(a, b)
print(a + " " + b)

# 4 Guardar dois numeros em variaveis diferentes
numero1 = 2
numero2 = 12
# 4.1 Soma
print(numero1 + numero2)
# 4.2 Subtração
print(numero1 - numero2)
# 4.3 Multiplicação
print(numero1 * numero2)
# 4.4 Divisão
print(numero1 / numero2)
# 4.5 Resto
print(numero1 % numero2)
# 4.6 Divisão inteira
print(numero1 // numero2)
# 4.7 A potencia uma do outro
# 4.7.1 **
# 4.7.2 Agora importa uma biblioteca (Numpy) e faz o exercicio 4.7

# 5 Cria uma lista com estes elementos: 1, "Ola", 4, 0.3, "8"
lista = [1, "ola", 4, 0.3, "8"]
# 5.1 Soma para cada elemento o valor 10
lista[0] + 10
lista[1] + 10
lista[2] + 10
lista[3] + 10
lista[4] + 10
# Nota: As listas começam em 0.

# print(a[1] + 10)  # Deu erro. Como fazemos para conseguirmos escrever Ola10?
print(a[1] + "10")
print(a[1] + str(10))

print(a[2] + 10)
print(a[3] + 10)
# print(a[4] + 10)  # Deu erro. Agora já sabemos como resolver.

# 6 Inputs
# 6.1 Pede ao utilizador o seu nome, guarda numa variavel e apresenta-o.
nome = input("Nome: ")
print(nome)
# Ora nos lemos sempre uma string (porque são letras) ! Não se esqueçam

# 6.2 Pede ao utilizador o seu primeiro e ultimo nome e mostra o nome completo
nome = input("Nome: ")
apelido = input("Apelido: ")
print(nome + " " + apelido)
# ou
total = nome + " " + apelido
print(total)

# 6.3 Pede ao utilizador um numero. Se
# esse numero for igual ao numero de letras que o teu primeiro nome tem "Tamanho Igual Urra!" e se não escreve
# "Tamanho diferente! :("
a = input("Escreve o teu nome\n")
b = input("Escreve um numero\n")

print(len(a))
print(b)
# Se fizermos if b == len(a) vai dar mal. Porque b é uma string
if int(b) == len(a):  # Temos que comparar numeros com numeros de modo a estabelecer uma igualdade válida!
    # atenção tudo o que dentro deste if tem que estar um "tab" para a frente!!!!!!!
    print("Tamanho Igual Urra!")
else:
    print("Tamanho diferente :(")


# 7 Funções
# Faz com uma função o exercicio anterior mas com um parametro como o nome e o outro com o numero
def func(a, b):
    if int(b) == len(a):  # Temos que comparar numeros com numeros de modo a estabelecer uma igualdade válida!
        # atenção tudo o que dentro deste if tem que estar um "tab" para a frente!!!!!!!
        print("Tamanho Igual Urra!")
    else:
        print("Tamanho diferente :(")


func("oal", 3)

# 8 Com a mesma lista e ve se ela contem o numero 4
lista = [1, "ola", 4, 0.3, "8"]

# Explorar estes 3 métodos nos proximos exercicios.
# for ele in lista
for ele in lista:
    print(ele)

# for i in range(0,len(lista))
for i in range(0,len(lista)):
    print(lista[i])

# for i in range(len(lista))
for i in range(len(lista)):
    print(lista[i])

# 8.1 Faz o exercicio com um ciclo while.
while lista:
    print(lista)
# 8.2 Faz com um ciclo for.
# 8.3 Não faças com um ciclo.
# 8.3.1 Com este metodo ve se a lista contem o numero 4 OU o numero 3 "or"
# if 3 in a or 4 in a:
# 8.3.2 Com o mesmo método ve se a lista contem uma string a dizer 8 E o numero 0.3 "and"

# 9 Com o auxilio do modulo turtle desenha um quadrado azul
# 9.1 Pinta agora o quadrado de verde
import turtle as t

# 9
# 9.1 Desenha o campo do jogo do Galo (sem usar um sistema de coordenadas)
# com um quadrado no centro do jogo. Podes escolher as dimensões que quiseres.

# Pontos Bonus se fizeres com funções passando as respectivas dimensões como parâmetros e se estiver bem centrado

screen = t.Screen()
screen.setup(800, 800)
screen.title("Jogo do Galo")

t.width(8)

def desenhar(largura, xi, yi):
    # code for inner lines of the square

    xi, yi = xi - largura / 6, yi - largura / 6  # metade do campo para baixo
    t.penup()
    t.goto(xi - largura / 3, yi)  # http://prntscr.com/1djqeb9
    t.pendown()

    t.forward(largura)

    t.penup()
    t.goto(xi - largura / 3, yi + largura / 3)
    t.pendown()

    t.forward(largura)

    t.penup()
    t.goto(xi, yi - largura / 3)
    t.pendown()

    t.left(90)
    t.forward(largura)

    t.penup()
    t.goto(xi + largura / 3, yi - largura / 3)
    t.pendown()

    t.forward(largura)

    desenharquad((largura/3)-largura/(3*4), 0, 0)


def desenharquad(comprimento, x, y):
    t.color('blue')
    t.up()
    t.goto((x - comprimento)/3, (y - comprimento)/3)  # tenho que dividir por 3 para estar no plano do jogo do galo
    t.down()

    t.seth(0)
    for x in range(4):
        t.forward(comprimento-comprimento/3)  # e dividir a largura do comprimento outra vez por 3 de modo a "caber" dentro do quadrado
        t.left(90)


desenhar(400, 0, 0)


t.done()

# 9.2 Escreve o teu nome no turtle (t.write("hello"))

def escrevealgo(frase):
    t.up()
    t.setpos(100, -100)
    t.down()

    t.write(frase)
    t.done()


escrevealgo("CORREIA+EDUARDO = SUPER FIXE")


# 9.3