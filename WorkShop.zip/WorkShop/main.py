import turtle as t

screen = t.Screen()
screen.setup(800, 800)
screen.title("Jogo do Galo")

t.width(8)



t.speed(2)
def desenharcampo(largura, xi, yi):
    # code for inner lines of the square

    xi , yi = xi-largura/6,yi-largura/6 #metade do campo para baixo
    t.penup()
    t.goto(xi-largura/3, yi) # http://prntscr.com/1djqeb9
    t.pendown()

    t.forward(largura)

    t.penup()
    t.goto(xi-largura/3, yi+largura/3)
    t.pendown()

    t.forward(largura)

    t.penup()
    t.goto(xi, yi-largura/3)
    t.pendown()

    t.left(90)
    t.forward(largura)

    t.penup()
    t.goto(xi+largura/3, yi-largura/3)
    t.pendown()

    t.forward(largura)


desenharcampo(300,0,0)

t.done()
