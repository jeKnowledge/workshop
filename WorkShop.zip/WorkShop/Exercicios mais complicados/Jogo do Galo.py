import turtle

screen = turtle.Screen()
screen.setup(800, 800)
screen.title("Jogo do Galo")
screen.setworldcoordinates(-5, -5, 5, 5)  # http://prntscr.com/1dhv72f

"""
!Explicar primeiro isto:

    Cria um sistema de coordenadas no campo assim:
    
        (-2, 2) (-1, 2) (0, 2) (1, 2) (2, 2)
        (-2, 1) (-1, 1) (0, 1) (1, 1) (2, 1)
        (-2, 0) (-1, 0) (0, 0) (1, 0) (2, 0)
        (-2,-1) (-1,-1) (0,-1) (1,-1) (2,-1)
        (-2,-2) (-1,-2) (0,-2) (1,-2) (2,-2)
 
    Para desenhar as linhas e as figuras
    Neste caso teria de desenhar "pontos" nas coordenadas que anotei:
 
        (-2, 2) LINHA (0, 2) LINHA (2, 2)
        LINHA   LINHA LINHA  LINHA  LINHA
        (-2, 0) LINHA (0, 0) LINHA (2, 0)
        LINHA   LINHA LINHA  LINHA LINHA
        (-2,-2) LINHA (0,-2) LINHA (2,-2)
        
        Para dar o jogo do galo.
        
        Se o X jogasse no meio qual é a coordenada que teria de desenhar o X?
        E se o 0 jogasse no canto inferior direito?
        
        Há alguma maneira de "universalizar" o local da matriz de jogadas com a coordenada que tenho de desenhar?
        (Nota: A matriz de jogadas é 3x3 (porque so se pode jogar jogadas nos espaços livres) e tem este formato: [i][j]
            (0, 0) (0, 1) (0, 2) 
            (1, 0) (1, 1) (1, 2) 
            (2, 0) (2, 1) (2, 2)
            
            Por exemplo joguei no local (1,2) logo tenho de desenhar no ponto (2,0)
        Sim: 
            x = 2 * (j - 1)
            y = -2 * (i - 1)
        
"""
screen.tracer(0, 0)
turtle.hideturtle()


def desenhacampo():  # http://prntscr.com/1dhw0so
    turtle.pencolor('black')
    turtle.pensize(10)  # aumentar a grossura

    turtle.up()
    turtle.goto(-3, -1)
    turtle.seth(0)
    turtle.down()
    turtle.forward(6)
    turtle.up()
    turtle.goto(-3, 1)
    turtle.seth(0)
    turtle.down()
    turtle.forward(6)
    turtle.up()
    turtle.goto(-1, -3)
    turtle.seth(90)
    turtle.down()
    turtle.forward(6)
    turtle.up()
    turtle.goto(1, -3)
    turtle.seth(90)
    turtle.down()
    turtle.forward(6)


def desnharcirculo(x, y):
    turtle.up()
    turtle.goto(x, y - 0.75)
    turtle.seth(0)
    turtle.color('red')
    turtle.down()
    turtle.circle(0.75, steps=100)  # para não se notar as pontas do circulo faz se steps=100


def desnharx(x, y):
    turtle.color('blue')
    turtle.up()
    turtle.goto(x - 0.75, y - 0.75)
    turtle.down()
    turtle.goto(x + 0.75, y + 0.75)
    turtle.up()
    turtle.goto(x - 0.75, y + 0.75)
    turtle.down()
    turtle.goto(x + 0.75, y - 0.75)


def jogoperdido(jogadas):
    """
        Esta função server para ver o que está a acontecer no jogo.

        Dou return:
            0- Nada aconteceu.
            1- X ganhou.
            2- O ganhou.
            3- Empate.
    """

    # Vejo se alguem ganhou no geral, escrevo todas as formas possiveis de ganhar e dou return ao numero que ganhou
    # se o X ganhar dou return a 1, se o O ganhar dou return a 2
    if jogadas[0][0] > 0 and jogadas[0][0] == jogadas[0][1] and jogadas[0][1] == jogadas[0][2]:
        return jogadas[0][0]
    if jogadas[1][0] > 0 and jogadas[1][0] == jogadas[1][1] and jogadas[1][1] == jogadas[1][2]:
        return jogadas[1][0]
    if jogadas[2][0] > 0 and jogadas[2][0] == jogadas[2][1] and jogadas[2][1] == jogadas[2][2]:
        return jogadas[2][0]
    if jogadas[0][0] > 0 and jogadas[0][0] == jogadas[1][0] and jogadas[1][0] == jogadas[2][0]:
        return jogadas[0][0]
    if jogadas[0][1] > 0 and jogadas[0][1] == jogadas[1][1] and jogadas[1][1] == jogadas[2][1]:
        return jogadas[0][1]
    if jogadas[0][2] > 0 and jogadas[0][2] == jogadas[1][2] and jogadas[1][2] == jogadas[2][2]:
        return jogadas[0][2]
    if jogadas[0][0] > 0 and jogadas[0][0] == jogadas[1][1] and jogadas[1][1] == jogadas[2][2]:
        return jogadas[0][0]
    if jogadas[2][0] > 0 and jogadas[2][0] == jogadas[1][1] and jogadas[1][1] == jogadas[0][2]:
        return jogadas[2][0]

    nrdejogadas = 0
    # Contar o numero de jogadas.
    for i in range(3):
        for j in range(3):
            if jogadas[i][j] > 0:
                nrdejogadas += 1  # vou pela matriz ver quantas vezes já joguei para ver se empatei.

    # Se for 9 jogadas paro e declaro empate
    if nrdejogadas == 9:
        return 3  # Empate, se forem jogadas 9 vezes e ninguem tiver ganho.
    else:
        return 0  # Não acontece nada, caso normal.


def joguei(x, y):
    global turn
    """
        (x e y são as coordenadas do rato em que tocamos) 
        
        Se 3 > y > 1 então i = 0, estou na primeira linha.
        Se 1 > y > -1 então i = 1, estou na segunda linha.
        Se -1 > y > -3 então i = 2, estou na terceira linha.
        
        Se -3 < x < -1 então j = 0, estou na primeira coluna.
        Se -1 < x < 1 então j = 1, estou na segunda coluna.
        Se 1 < x < 3 então j = 2, estou na terceira coluna.
        
        (i e j são as coordenadas do nosso jogo)
        
    """
    i = 3 - int(y + 5) // 2  # vou ver em que coordenada Y é que desenhei algo
    print(f"y:{y}, i:{i}")
    j = int(x + 5) // 2 - 1  # vou ver em que coordenada X é que desenhei algo
    print(f"x:{x}, j:{j}\n")
    if i > 2 or j > 2 or i < 0 or j < 0 or jogadas[i][j] != 0:
        return  # estamos fora da matriz ou já foi jogado naquele quadrado, não faço nada

    if turn == 'x':
        jogadas[i][j] = 1  # escrevo a jogada do x na nossa matriz
        turn = 'o'
    else:
        jogadas[i][j] = 2  # escrevo a jogada do y na nossa matriz
        turn = 'x'

    print(jogadas)

    atualizadesenho(jogadas)
    r = jogoperdido(jogadas)
    # ecrãs finais
    if r == 1:
        screen.textinput("Game over!", "\"X\" ganhou!")
        screen.clear()
    elif r == 2:
        screen.textinput("Game over!", "\"O\" ganhou!")
        screen.clear()
    elif r == 3:
        screen.textinput("Game over!", "Empate!")
        screen.clear()


def atualizadesenho(jogadas):
    """
         Esta função dá update ao ecrã do jogo quando algo acontece
    """

    # vou por todas as casas até encontrar a casa que foi jogada para escrever no sitio dela um X ou um O.
    for i in range(3):
        for j in range(3):  # vou percorrer todas as colunas e todas as linhas
            if jogadas[i][j] == 0:
                continue  # vejo se já joguei. Se sim não estiver jogada na matriz Jogdas (um 0) não faço nada, passo o loop.
            """
            Exemplo, se na matriz estiver uma jogada no lugar (1,1) ou seja

            [0, 0, 0]
            [0, 1, 0]
            [0, 0, 0] 

            Eu preciso de escrever um X na posição do campo (x=0 e y=0) (o centro)
            de acordo com as coordenadas do campo que escrevemos.
            """
            x = 2 * (j - 1)
            y = -2 * (i - 1)

            # Se na matriz houver jogadas (além do 0):
            # da matriz que aponto as jogadas desenho X ou O no campo dependendo das jogadas.
            if jogadas[i][j] == 1:  # se na matriz Jogadas estiver um 1 desenho um X
                desnharx(x, y)
            else:  # se na matriz Jogadas estiver um 2 desenho um Y
                desnharcirculo(x, y)

            screen.update()


jogadas = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0]
]

desenhacampo()

screen.update()

turn = 'x'

screen.onclick(joguei)

turtle.mainloop()
