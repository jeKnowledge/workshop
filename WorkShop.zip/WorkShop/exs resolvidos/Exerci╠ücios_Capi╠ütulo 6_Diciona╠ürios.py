#6.10
def posicoes(cadeia):
    dicio=dict()
    vogais='aeiouAEIOU' # ou uma lista de vogais
    for i in range(len(cadeia)):
        car=cadeia[i]
        if car in vogais:
            #if car not in dicio:
                #dicio[car]=[i]
            #else:
                #dicio[car]+=[i] # ou dicio[car].append(i)
            #alternativamente:
            dicio[car]=dicio.get(car,[])+[i]
    return dicio

#6.11
def dicio_linguagens():
    autor={"php":"Rasmus Lerdorf","perl":"LarryWall","tcl":"John Ousterhout","awk":"Brian Kernighan","java":"James Gosling","parrot":"Simon Cozens","python":"GuidovanRossum","xpto":"zxcv"}
    autor['nova']='autor_novo'
    autor['python']='Guido van Rossum'
    del autor['xpto']
    print(len(autor))
    print(autor)
    return "c++" in autor
    
#6.12
def stock_fruta(nome_frutas,quantidades):
    stock={} # ou stock()
    for i in range(len(nome_frutas)):
        chave=nome_frutas[i]
        valor=quantidades[i]
        stock[chave]=valor
    return stock

#6.13
def gestao_loja(nome_frutas):
    dicio={}
    for i in range(len(nome_frutas)):
        qtdd_comprada=eval(input("Quantidade de {} comprada: ".format(nome_frutas[i])))
        preco_compra=eval(input("Pre�o de compra por quilo: "))
        qtdd_stock=eval(input("Quantidade em stock: "))
        preco_venda=eval(input("Pre�o de venda por quilo: "))
        qttd_vendida=qtdd_comprada-qtdd_stock
        lucro=qttd_vendida*(preco_venda-preco_compra)
        dicio[nome_frutas[i]]=[preco_compra,lucro]
        print()
    print(dicio)
    maior=0
    lucro_total=0
    for i in range(len(nome_frutas)):
        lucro_total+=dicio[nome_frutas[i]][1]
        if dicio[nome_frutas[i]][0]>maior:
            nome_maior=nome_frutas[i]
    print(lucro_total,nome_maior)

#6.14
dias_semana={1:'Domingo',2:'Segunda-Feira',3:'Ter�a-Feira',4:'Quarta-Feira',5:'Quinta-Feira',6:'Sexta-Feira',7:'S�bado'}
meses_ano={1:'Janeiro',2:'Fevereiro',3:'Mar�o',4:'Abril',5:'Maio',6:'Junho',7:'Julho',8:'Agosto',9:'Setembro',10:'Outubro',11:'Novembro',12:'Dezembro'}
def conversor(dias_semana,meses_ano,data):
    nova_data=data.split('/')
    print("{0}, {1} de {2} de {3}".format(dias_semana[int(nova_data[0])],nova_data[1],meses_ano[int(nova_data[2])],nova_data[3]))
    
#6.15
def racio(sexo,peso,altura,idade):
    if sexo=='Masculino':
        racio=66+(6.3*peso)+(12.9*altura)-(6.8*idade)
    else:
        racio=655+(4.3*peso)+(4.7*altura)-(4.7*idade)
    return racio

def dicio_racio(dicio):
    novo_dicio={}
    for chave,valor in dicio.items():
        novo_dicio[chave]=novo_dicio.get(chave,[])+[racio(valor['sexo'],valor['peso'],valor['altura'],valor['idade'])]
    return novo_dicio

#6.17
def inverte(dicio):
    novo_dicio=dict()
    for c,v in dicio.items():
        #tratar chaves mut�veis
        if type(v)==list:
            v=tuple(v)
        elif type(v)==dict:
            v=tuple(v.items())
        novo_dicio[v]=novo_dicio.get(v,[])+[c]
        #equivalente a:
        #if v in novo_dicio:
            #novo_dicio[v]+=[c]
        #else:
            #novo_dicio[v]=[c]
    return novo_dicio

#6.18
def progenitor(arv_gen, pessoa):
    for c in arv_gen:
        if pessoa in arv_gen[c]:
            return c
    return None

def irmandade(arvore,p1,p2):
    prog1=progenitor(arvore,p1)
    prog2=progenitor(arvore,p2)
    return prog1==prog2
    #if progenitor(arvore,p1)==progenitor(arvore,p2):
        #print('Que lindo! Sois irm�os!')
    #else:
        #print('Oh! N�o sois irm�os!')

#6.19
def filhos(arvore,nome):
    filhos=arvore.get(nome,None)
    return filhos

def netos(arvore,nome):
    descendentes=filhos(arvore,nome)
    if descendentes!=None:
        netos=[]
        for val in descendentes:
            netos+=filhos(arvore,val)
        return netos
    return 'ERROR: No granchildren found!!'

#6.20
def avo(dicio,nome):
    pai=progenitor(dicio,nome)
    if pai!=None:
        avo=progenitor(dicio,pai)
        return avo
    return None