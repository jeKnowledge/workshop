import turtle

def circulo(raio,xcor,ycor,r,g,b):
    turtle.colormode(255)
    turtle.pencolor(r,g,b)
    turtle.pensize(3)
    turtle.penup()
    turtle.goto(xcor,ycor)
    turtle.pendown()
    turtle.hideturtle()
    turtle.circle(raio)

def jogos_olimpicos(raio):
    x=turtle.xcor()
    y=turtle.ycor()
    for i in range(5):
        r=eval(input("Valor de r? "))
        g=eval(input("Valor de g? "))
        b=eval(input("Valor de b? "))
        if i%2!=0:
            circulo(raio,x+raio*i+5*i,y,r,g,b)
        else:
            circulo(raio,x+raio*i+5*i,y+raio,r,g,b)
    turtle.exitonclick()

jogos_olimpicos(50)