#6.1
def idades(lista,numero):
    print(len(lista))#n�mero de idades
    print(lista)#todas as idades da lista
    inversa=lista[:]
    inversa.reverse()
    print(inversa)#idades na ordem inversa
    print(lista[1:len(lista)-1])#todas as idades excepto 1� e �ltima
    lista.sort()
    print(lista[0],lista[len(lista)-1])#idade maior e idade menor
    soma=0
    for i in range(len(lista)):
        soma=soma+int(lista[i])
    print(soma)#soma das idades
    ocorrencias=0
    for i in range(numero):
        ocorrencias=ocorrencias+int(lista.count(i))
    print(ocorrencias)#n�mero de idades inferiores a um determinado valor
    return (17 in lista)#aluno com 17 anos

#6.2
def somas(lista):
    pares=0
    impares=0
    for val in lista:
        if val%2==0:
            pares+=val
        else:
            impares+=val
    print(pares,impares)
    
#6.3
def alternado(l1,l2):
    l3=[]
    if len(l1)>len(l2):
        maior=l1
        tamanho_menor=len(l2)
    else:
        maior=l2
        tamanho_menor=len(l1)
    for i in range(tamanho_menor):
        l3.append(l1[i])
        l3.append(l2[i])
    l3=l3+maior[tamanho_menor:]
    print(l3)
            
    """if len(l1)==len(l2):
        for i in range(len(l1)):
            l3.append(l1[i])
            l3.append(l2[i])        
    elif len(l1)<len(l2):
        for i in range(len(l1)):
            l3.append(l1[i])
            l3.append(l2[i])
        for i in range(len(l1),len(l2)):
            l3.append(l2[i])
    else:
        for i in range(len(l2)):
            l3.append(l1[i])
            l3.append(l2[i])
        for i in range(len(l2),len(l1)):
            l3.append(l1[i])
    print(l3)"""
    
#6.4
def menores(n,lista):
    conta=0
    for i in range(len(lista)):
        if lista[i]<n:
            conta+=1
    print(conta)
    
#6.5
import random
def dados(vezes):
    conta=0
    lista_somas=[]
    for i in range(vezes):
        dado1=random.randint(1,6)
        dado2=random.randint(1,6)
        soma=dado1+dado2
        lista_somas.append(soma)
    for i in range(len(lista_somas)):
        if lista_somas[i]%2==0:
            conta+=1
    print("Percentagem = {:.2f} %".format(conta/vezes*100))
    
#6.6
def cumulativa(lista):
    lista_nova=[]
    for i in range(len(lista)):
        lista_nova.append(0)
        for j in range(i+1):
            lista_nova[i]=lista_nova[i]+lista[j]
    print(lista_nova)

#6.7
import copy
def negativo(img):
    copia=copy.deepcopy(img)
    linhas=len(img)
    colunas=len(img[0])
    for linha in range(linhas):
        for coluna in range(colunas):
            if copia[linha][coluna]==1:
                copia[linha][coluna]=0
            else:
                copia[linha][coluna]=1
    return copia

#6.8
def roda(img):
    nova_matriz = []
    linhas_img=len(img)
    colunas_img=len(img[0])    
    
    for i in range(colunas_img):
        nova_linha = []
        for j in range(linhas_img):
            nova_linha.append(0)
        nova_matriz.append(nova_linha)
    
    for i in range(colunas_img):
        for j in range(linhas_img):
            nova_matriz[i][j]=img[linhas_img-1-j][i]
    print(nova_matriz)
    
#6.9
import turtle
def gera_comandos(n):
    comandos=[]
    for i in range(n):
        passo=eval(input("Introduza a indica��o: "))
        comandos.append(passo)
    return comandos

def navega(comandos):
    for i in range(len(comandos)):
        if comandos[i]=='A':
            turtle.forward(50)
        elif comandos[i]=='R':
            turtle.back(50)
        elif comandos[i]=='E':
            turtle.left(90)
        else:
            turtle.right(90)
            
def dir(n):
    comandos_gerados=gera_comandos(n)
    navega(comandos_gerados)
    turtle.exitonclick()