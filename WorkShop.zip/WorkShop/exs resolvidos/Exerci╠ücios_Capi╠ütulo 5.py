#5.1
def milhas(inicio,fim):
    milha=1.609
    print("Milhas\t\tQuil�metros")
    print("----------------------------")
    for i in range(inicio,fim+1):
        print("{0:.2f} \t\t {1:.2f}".format(i,i*milha))
        
#5.2
def ordenacao(x,y,z):
    if(x<=y and x<=z):
        if(y<=z):
            print(x,y,z)
        else:
            print(x,z,y)
    elif(y<=z):
        if(x<=z):
            print(y,x,z)
        else:
            print(y,z,x)
    elif(x<=y):
        print(z,x,y)
    else:
        print(z,y,x)
        
#5.3
def custo():
    estrada=eval(input("Qual a sua escolha?\nPara A1 prima 1\nPara A20 prima 2\nPara A21 prima 3\n"))
    if(estrada==1):
        print("O custo total da viagem ser�",0.15*120+6.52)
    elif(estrada==2):
        print("O custo total da viagem ser�",0.12*120+15.2)
    elif(estrada==3):
        print("O custo total da viagem ser�",0.1*120+5.75)
    else:
        print("Escolha inv�lida!")

#5.4
def vencimento(bruto):
    print("O vencimento l�quido correspondente a {0} � {1:.2f}".format(bruto,0.6*bruto))

#5.5
def nota(t1,t2,t3,t4,e):
    media=0.075*(t1+t2+t3+t4)+0.7*e
    if(media>=14):
        print("Aprovado")
    elif(media>=7):
        print("Oral")
    else:
        print("Reprovado")

#5.6
def ciclo_f():
    for i in range(20,-1,-2):
        print("i=",i)

#5.7
"""for i in range(3):
    for j in range(1,3):
        print (float(i)/j)"""

#5.8
def amigas():
    conta=0
    p1=eval(input("Introduza a primeira palavra: "))
    p2=eval(input("Introduza a segunda palavra: "))
    while (len(p1)!=len(p2)):
        print("Introduza palavras com o mesmo comprimento!")
        p1=eval(input("Introduza a primeira palavra: "))
        p2=eval(input("Introduza a segunda palavra: "))
    for i in range(len(p1)):
        if p1[i]!=p2[i]:
            conta=conta+1
    if (conta/len(p1)<0.1*len(p1)):
        print("As palavras s�o amigas")
    else:
        print("As palavras n�o s�o amigas")
                
#5.9
def divisor_primo(numero):
    for i in range(1,numero+1):
        resto=numero%i
        if resto==0:
            if i==1:
                continue
            elif i==numero:
                print ("� primo!")
            else:
                print("O menor divisor do n�mero �: ",i)
                print("N�o � primo!")
                break
        else:
            continue

#5.10
import random
def dado(n):
    pares=0
    for i in range(n):
        face=random.randint(1,6)
        if face%2==0:
            pares=pares+1
    print("Saiu um n�mero par {0:.2f}% vezes".format(pares/n*100))
    
#5.11
def probabilidade(num_dardos):
    conta=0
    for i in range(num_dardos):
        x=random.uniform(0,2)
        y=random.uniform(0,2)
        if(x<1 and y>1):
            conta=conta+1
        elif(x>1 and y<x):
            conta=conta+1
    prob=conta/num_dardos*100
    print("A probabilidade de cair na regi�o �mpar �: ",prob)

#5.12
def fact(n):
    factorial=1
    for i in range(n,0,-1):
        factorial=factorial*i
    print (factorial)

#5.13
import math
def seno(x,n):
    seno=0
    anterior=0
    for i in range(n+1):
        parcela=((-1)**i*x**(2*i+1))/math.factorial(2*i+1)
        dif = abs(parcela-anterior)
        seno=seno+parcela
        anterior = parcela
    return seno

def seno_precisao(x,pres):
    seno=0
    anterior=0
    dif=pres+1
    i=0
    while dif>pres:
        parcela=((-1)**i*x**(2*i+1))/math.factorial(2*i+1)
        dif = abs(parcela-anterior)
        seno=seno+parcela
        anterior = parcela
        i+=1
    return seno

import matplotlib.pyplot as plt
def grafico(nomex,nomey,titulo,tuplo_dados):
    plt.xlabel(nomex)
    plt.ylabel(nomey)
    plt.title(titulo)
    plt.plot(tuplo_dados)
    plt.show()
    
#5.14
def harmonico(n):
    harm=0
    for i in range(1,n+1):
        harm=harm+(1/i)
    return harm

def num_harm(n):
    tuplo = ()
    for j in range(n):
        res = harmonico(j)
        tuplo = tuplo + (res,)
    grafico("n","H","N�mero Harm�nico",tuplo)

#5.15
def harmonico_novo(n):
    euler=0.5772156649
    harm=math.log(n)+euler
    return harm
    
def num_harm_novo(n):
    tuplo = ()
    for i in range(1,n+1):
        res = harmonico_novo(i)
        tuplo = tuplo + (res,)
    grafico("n","H","N�mero Harm�nico",tuplo)

#5.16
def expo(n):
    e=0
    for i in range(0,n+1):
        e+=1/math.factorial(i)
    return e

def expo_precisao(pres):
    e=0
    e_anterior=0
    dif=pres+1
    i=0
    while dif>pres:
        parcela=1/math.factorial(i)
        e=e+parcela
        dif=abs(e-e_anterior)
        e_anterior=e
        i+=1
    return e

#5.17
def divisores(x):
    soma_div=0
    for i in range(1,x):
        if x%i==0:
            soma_div+=i
    return soma_div

def perfeito(n):
    for i in range(1,n+1):
        if divisores(i)==i:
            print(i)
            
#5.18
def padrao_a(n):
    for i in range(1,n+1):
        for j in range(1,i+1):
            print(j,end=' ')
        print("")

def padrao_b(n):
    for i in range(1,n+1):
        for j in range(1,n-i+2):
            print(j,end=' ')
        print("")    
    
def padrao_c(n):
    for limite in range(1,n+1): #limite por cada linha
        espacos="   "*(n-limite)
        print(espacos,end='')            
        for j in range(limite,0,-1):
            #print(j,end=' ')
            print("{:>2d}".format(j),end=' ')
        print()
        
#5.19
import turtle
def posicionar(x,y,grau):
    turtle.hideturtle()
    turtle.penup()
    turtle.goto(x,y)
    turtle.pendown()
    turtle.setheading(grau)
        
def grelha(dimensao,tamanho):
    altura=0
    largura=0
    while altura<=dimensao:
        posicionar(largura,altura,0)
        turtle.forward(dimensao)
        altura+=tamanho
    while largura<=dimensao:
        posicionar(largura,dimensao,-90)
        turtle.forward(dimensao)
        largura+=tamanho    
    turtle.exitonclick()
    
#5.21
def fibonacci(n):
    fibo=[1]
    i=0
    while fibo[i]<=n:
        i+=1
        if (i==1):
            fibo.append(1)
        else:
            elemento=fibo[i-2]+fibo[i-1]
            fibo.append(elemento)
    return fibo

def procura(n):
    return n in fibonacci(n)