import math
import turtle

#3.2
def heron(a,b,c):
    s=(a+b+c)/2
    area=math.sqrt(s*(s-a)*(s-b)*(s-c))
    print ("A area do triangulo �: ",area)
    
#3.3
def escada(alt,ang):
    ang=ang*(math.pi/180)
    comp=(alt/math.sin(ang))
    print("O comprimento da escada �: ",comp)
    
#3.4
def batimento(idade):
    batimento=163+1.16*idade-0.018*idade**2
    print("O valor m�dio do batimento m�ximo �: ",batimento)

#3.5
def dinheiro(v,t,a):
    dinheiro=v*(1+t)**a
    print("Ao fim de ",a, "anos tem ",dinheiro,"euros")
    i=0
    dinheiro_novo=0
    while dinheiro_novo<2*v:
        i+=1
        dinheiro_novo=v*(1*t)**i
    print("Passados ",i,"anos consegue duplicar o seu dinheiro")
    
#3.11
"""def troca(texto):
    vogais="aeiou"
    for i in range(len(vogais)):
        for j in range(len(texto)):
            if texto[j]==vogais[i]:
                texto=texto[:j]+" "+texto[j+1:]
    return texto"""

def troca(texto):
    vogais="aeiouAEIOU"
    for i in range(len(vogais)):
        texto=texto.replace(vogais[i]," ")
    return texto

def subs(cadeia):
    vogais="aeiou"
    for c in vogais:
        cadeia=cadeia.replace(c," ")
    return cadeia

#3.12
def subcadeias(cadeia,numero):
    for i in range(len(cadeia)-numero+1):
        print(cadeia[i:i+numero])

#3.13
def prefixos(cadeia):
    for i in range(len(cadeia)):
        print(cadeia[:i+1])

#3.14
def sufixos(cadeia):
    for i in range(len(cadeia)):
        print(cadeia[-i-1:])

#3.15
def tarta(adn,comp,ang):
    for i in range(len(adn)):
        if adn[i]=="f":
            turtle.forward(comp)
        elif adn[i]=="e":
            turtle.left(ang)
        elif adn[i]=="t":
            turtle.backward(comp)
        elif adn[i]=="d":
            turtle.right(ang)
        else:
            print("Esse ADN n�o � v�lido!")
    turtle.exitonclick()