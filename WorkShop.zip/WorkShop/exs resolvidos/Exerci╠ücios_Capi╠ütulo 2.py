import turtle
import random
import math

#2.1
def estrela():
    for i in range(5):
        turtle.forward(100)
        turtle.right(144)
    turtle.exitonclick()
    
#2.2
def walk(num_tracos):
    turtle.colormode(255)
    for i in range(num_tracos):
        r=random.randint(0,255)
        g=random.randint(0,255)
        b=random.randint(0,255)
        turtle.pencolor(r,g,b)
        comp=random.randint(0,100)
        turtle.forward(comp)
        angulo=random.randint(0,360)
        turtle.right(angulo)
    turtle.exitonclick()

#2.3
def circulo(raio,num_lados):
    perimetro=2*math.pi*raio
    comp=perimetro/num_lados
    for i in range(num_lados):
        turtle.forward(comp)
        turtle.right(360/num_lados)
    turtle.exitonclick()
        
#2.4
def poligonos():
    num_lados=eval(input("Numero de lados do poligono? "))
    raio=100
    turtle.circle(raio,steps=num_lados)
    turtle.exitonclick()

#2.5
def quadrados():
    num_quadrados=eval(input("Quantos quadrados quer desenhar? "))
    for i in range(num_quadrados):
        turtle.penup()
        turtle.goto((50-10*i,50+10*i))
        turtle.pendown()
        for j in range(4):
            turtle.forward(50+20*i)
            turtle.right(90)
    turtle.exitonclick()
    
#2.5
def quadrado(tamanho_lado,xcor,ycor,orient):
    turtle.penup()
    turtle.goto(xcor,ycor)
    turtle.setheading(orient)
    turtle.pendown()
    for i in range(4):
        turtle.forward(tamanho_lado)
        turtle.right(90)
    turtle.hideturtle()
    
def quad_conc(num,comp_lado,dist):
    x=turtle.xcor()
    y=turtle.ycor()
    for i in range(num):
        tamanho_lado=comp_lado+i*2*dist
        quadrado(tamanho_lado,x-i*dist,y+i*dist,0)
    
#2.6
def espiral():
    num_quadrados=eval(input("Quantos quadrados quer desenhar? "))
    for i in range(num_quadrados):
        turtle.setheading(-300+10*i)
        for j in range(4):
            turtle.forward(10+10*i)
            turtle.right(90)
    turtle.exitonclick()
    
#2.6
def nautilus(num,comp_lado,comp_seguinte,angulo_inicial,angulo):
    x=turtle.xcor()
    y=turtle.ycor()
    for i in range(num):
        tamanho_lado=comp_lado+i*comp_seguinte
        orient=angulo_inicial+i*angulo
        quadrado(tamanho_lado,x,y,orient)
    turtle.exitonclick()

quadrados()