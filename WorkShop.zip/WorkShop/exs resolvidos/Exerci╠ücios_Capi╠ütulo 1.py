# 1.5
def tijolos():
    largura = 6 / 2
    comprimento = 8 / 2
    tijolos = largura * comprimento
    return tijolos


# 1.7
def area_triangulo():
    base = eval(input("Introduza o valor da base: "))
    altura = eval(input("Introduza o valor da altura: "))
    area_triangulo = (base * altura) / 2
    print("A �rea do tri�ngulo �: ", area_triangulo)
    return area_triangulo


# 1.8
def burger():
    import math
    novo = 7.62 ** 2
    antigo = math.pi * (8.89 / 2) ** 2
    if novo < antigo:
        print("Deve protestar")
    else:
        print("N�o deve protestar")


# 1.9
def imc():
    altura = eval(input("Introduza a altura: "))
    peso = eval(input("Introduza o peso: "))
    imc = peso / altura ** 2
    return imc


# 1.10
def conversao():
    c = eval(input("Introduza a temperatura em graus Celsius: "))
    f = (9 / 5) * c + 32
    print("A temperatura em Fahrenheit �: ", f)


# 1.11
def volume_cone():
    import math
    r = eval(input("Introduza o raio: "))
    h = eval(input("Introduza a altura: "))
    volume_cone = (math.pi * r ** 2 * h) / 3
    print("Volume do cone: ", volume_cone)


# 1.12
def polinomio():
    x = eval(input("Introduza o valor de x: "))
    polinomio = x ** 4 + x ** 3 + 2 * x ** 2 - x
    return polinomio


# 1.14
def cambio():
    euros = eval(input("Introduza o valor em euros: "))
    dolares = euros / 0.7
    print("O valor em d�lares �: ", dolares)


# 1.15
def garrafas():
    x = eval(input("Introduza a quantidade de �gua: "))
    g1 = x // 5
    r1 = x % 5
    g2 = r1 // 1.5
    r2 = r1 % 1.5
    g3 = r2 // 0.5
    r3 = r2 % 0.5
    g4 = r3 // 0.25
    r4 = r3 % 0.25
    if r4 == 0:
        print("Garrafas de 5: ", g1, " Garrafas de 1.5: ", g2, " Garrafas de 0.5: ", g3, " Garrafas de 0.25: ", g4)
    else:
        g4 = g4 + 1
        print("Garrafas de 5: ", g1, " Garrafas de 1.5: ", g2, " Garrafas de 0.5: ", g3, " Garrafas de 0.25: ", g4)


# 1.16
import random


def adivinha():
    numero_secreto = random.randint(0, 100)
    for i in range(5):
        numero = eval(input("Numero: "))
        if numero == numero_secreto:
            return True
        else:
            if numero < numero_secreto:
                print("Numero secreto e maior")
            else:
                print("Numero secreto e menor")
    print("Esgotou as tentativas")


# 1.17
def coordenadas():
    import math
    x, y = eval(input("Introduza o valor de x e de y: "))
    r = math.sqrt(x ** 2 + y ** 2)
    angulo = math.atan(y / x)
    print("r=", r, "angulo=", angulo)


# 1.18
def periodo():
    import math
    a = eval(input("Introduza a dist�ncia em UA: "))
    p = math.sqrt(a ** 3)
    print("Per�odo: ", p)


# 1.18
def newton():
    import math
    g = 6.67e-11
    m1 = 0.31 * 1.98e30
    m2 = eval(input("Qual a massa do corpo? "))
    a = eval(input("Introduza a dist�ncia em UA: "))
    p = 2 * math.pi * math.sqrt((a ** 3) / (g * (m1 + m2)))
    print("Per�odo: ", p)
